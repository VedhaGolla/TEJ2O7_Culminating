import pygame

pygame.init()

# ---------------- SCREEN ----------------
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 600
gameDisplay = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT))
pygame.display.set_caption("RoadMaster")
clock = pygame.time.Clock()

# ---------------- COLORS ----------------
ORANGE = (255, 165, 60)
WHITE = (245, 245, 245)
GRAY = (160, 160, 160)
DARK_GRAY = (40, 40, 40)
BLACK = (0, 0, 0)

# ---------------- FONTS ----------------
title_font = pygame.font.SysFont(None, 72)
button_font = pygame.font.SysFont(None, 36)
subtitle_font = pygame.font.SysFont(None, 30)

# ---------------- BACKGROUNDS ----------------
background = pygame.image.load("Images/backgroundIMG.png")
background = pygame.transform.scale(background, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

credits_img = pygame.image.load("Images/exitScreen_background.png")
credits_img = pygame.transform.scale(
    credits_img, (DISPLAY_WIDTH, credits_img.get_height())
)
credits_y = DISPLAY_HEIGHT
scroll_speed = 1

# ---------------- GAME STATE ----------------
state = "title"

# ---------------- BUTTON SETUP ----------------
button_width = 140
button_height = 60
button_y = 350
spacing = 20
start_x = 10

lesson_button = pygame.Rect(start_x, button_y, button_width, button_height)
quiz_button = pygame.Rect(start_x + (button_width + spacing), button_y, button_width, button_height)
results_button = pygame.Rect(start_x + (button_width + spacing) * 2, button_y, button_width, button_height)
game_button = pygame.Rect(start_x + (button_width + spacing) * 3, button_y, button_width, button_height)
quit_button = pygame.Rect(start_x + (button_width + spacing) * 4, button_y, button_width, button_height)

start_button = pygame.Rect(
    (DISPLAY_WIDTH - button_width) // 2,
    350,
    button_width,
    button_height
)

back_button = pygame.Rect(DISPLAY_WIDTH - 120, DISPLAY_HEIGHT - 65, 100, 45)

# ---------------- FUNCTIONS ----------------
def draw_button(rect, text):
    mouse_pos = pygame.mouse.get_pos()

    if rect.collidepoint(mouse_pos):
        color = ORANGE
        text_color = BLACK
    else:
        color = DARK_GRAY
        text_color = WHITE

    pygame.draw.rect(gameDisplay, color, rect)

    text_surf = button_font.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    gameDisplay.blit(text_surf, text_rect)

def draw_background():
    gameDisplay.blit(background, (0, 0))
    overlay = pygame.Surface((DISPLAY_WIDTH, DISPLAY_HEIGHT))
    overlay.set_alpha(120)
    overlay.fill(BLACK)
    gameDisplay.blit(overlay, (0, 0))

def draw_title_screen():
    draw_background()
    gameDisplay.blit(title_font.render("RoadMaster", True, WHITE), (260, 180))
    gameDisplay.blit(
        subtitle_font.render(
            "A driving game built on precision, awareness, and real road rules.",
            True, GRAY
        ),
        (80, 235)
    )
    draw_button(start_button, "START")

def draw_menu_screen():
    draw_background()
    gameDisplay.blit(title_font.render("Main Menu", True, WHITE), (285, 160))
    draw_button(lesson_button, "LESSON")
    draw_button(quiz_button, "QUIZ")
    draw_button(results_button, "RESULTS")
    draw_button(game_button, "GAME")
    draw_button(quit_button, "QUIT")

def draw_lesson_screen():
    draw_background()
    gameDisplay.blit(button_font.render("Page under construction...", True, WHITE), (250, 160))
    draw_button(back_button, "BACK")

def draw_quiz_screen():
    draw_background()
    gameDisplay.blit(button_font.render("Page under construction...", True, WHITE), (250, 160))
    draw_button(back_button, "BACK")

def draw_results_screen():
    draw_background()
    gameDisplay.blit(button_font.render("Page under construction...", True, WHITE), (250, 160))
    draw_button(back_button, "BACK")

def draw_game_screen():
    draw_background()
    gameDisplay.blit(button_font.render("Page under construction...", True, WHITE), (250, 160))
    draw_button(back_button, "BACK")

def draw_quit_screen():
    global credits_y
    gameDisplay.fill(BLACK)
    gameDisplay.blit(credits_img, (0, credits_y))
    credits_y -= scroll_speed

# ---------------- MAIN LOOP ----------------
def gameLoop():
    global state, credits_y
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if state == "title" and start_button.collidepoint(event.pos):
                    state = "menu"

                elif state == "menu":
                    if lesson_button.collidepoint(event.pos):
                        state = "lesson"
                    elif quiz_button.collidepoint(event.pos):
                        state = "quiz"
                    elif results_button.collidepoint(event.pos):
                        state = "results"
                    elif game_button.collidepoint(event.pos):
                        state = "game"
                    elif quit_button.collidepoint(event.pos):
                        credits_y = DISPLAY_HEIGHT
                        state = "quit"

                elif state in ["lesson", "quiz", "results", "game"]:
                    if back_button.collidepoint(event.pos):
                        state = "menu"

        if state == "title":
            draw_title_screen()
        elif state == "menu":
            draw_menu_screen()
        elif state == "lesson":
            draw_lesson_screen()
        elif state == "quiz":
            draw_quiz_screen()
        elif state == "results":
            draw_results_screen()
        elif state == "game":
            draw_game_screen()
        elif state == "quit":
            draw_quit_screen()
            if credits_y + credits_img.get_height() < 0:
                running = False

        pygame.display.update()
        clock.tick(60)

    pygame.quit()

gameLoop()
