import pygame

pygame.init()

# ---------------- SCREEN ----------------
DISPLAY_WIDTH = 800
DISPLAY_HEIGHT = 600
gameDisplay = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT))
pygame.display.set_caption("RoadMaster")
clock = pygame.time.Clock()
# ---------------- COLORS ----------------
ORANGE = (255, 165, 60)
WHITE = (245, 245, 245)
GRAY = (160, 160, 160)
DARK_GRAY = (40, 40, 40)
BLACK = (0, 0, 0)
# ---------------- MUSIC ----------------
pygame.mixer.music.load("pygameMusic.mp3")
pygame.mixer.music.set_volume(0.2) 
pygame.mixer.music.play(-1, 0.0)
# ---------------- FONTS ----------------
title_font = pygame.font.SysFont(None, 72)
button_font = pygame.font.SysFont(None, 36)
subtitle_font = pygame.font.SysFont(None, 30)
paragraph_font = pygame.font.SysFont(None,25)

# ---------------- BACKGROUNDS ----------------
background = pygame.image.load("Images/backgroundIMG.png")
background = pygame.transform.scale(background, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

credits_img = pygame.image.load("Images/exitScreen_background.png")
credits_img = pygame.transform.scale(credits_img, (DISPLAY_WIDTH, credits_img.get_height()))
credits_y = DISPLAY_HEIGHT
scroll_speed = 1

# ---------------- GAME IMAGES ----------------
# Load road maps (we'll scroll these)
straight_road = pygame.image.load("Images/straight_road.png")
straight_road = pygame.transform.scale(straight_road, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

intersection_left = pygame.image.load("Images/intersection_left.png")
intersection_left = pygame.transform.scale(intersection_left, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

crosswalk_road = pygame.image.load("Images/crosswalk_road.png")
crosswalk_road = pygame.transform.scale(crosswalk_road, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

parking_lot = pygame.image.load("Images/parking_lot.png")
parking_lot = pygame.transform.scale(parking_lot, (DISPLAY_WIDTH, DISPLAY_HEIGHT))

# Load car and instructor
player_car_original = pygame.image.load("Images/player_car.png").convert_alpha()
player_car = pygame.transform.scale(player_car_original, (160, 170))

# Create rotated versions of car
player_car_left = pygame.transform.rotate(player_car, 15)   # Slight left tilt
player_car_right = pygame.transform.rotate(player_car, -15)  # Slight right tilt

instructor = pygame.image.load("Images/instructor.png")
instructor = pygame.transform.scale(instructor, (80, 80))

# Load pedestrian
pedestrian_img = pygame.image.load("Images/pedestrain.png")
pedestrian_img = pygame.transform.scale(pedestrian_img, (40, 60))

# ---------------- LESSON SLIDES ----------------
lesson_slides = []
for i in range(1, 12):
    img = pygame.image.load(f"Images/slide{i}.png")
    img = pygame.transform.scale(img, (DISPLAY_WIDTH, DISPLAY_HEIGHT))
    lesson_slides.append(img)

current_slide = 0

quiz_questions = [
    {
        "question": "What does a broken white line represent?",
        "choices": [
            "Lane changes are discouraged",
            "Lane changes are prohibited",
            "Lane changes are permitted",
            "Lane changes are allowed as long as the area is clear"
        ],
        "correct": 2,
        "reason": "Broken white lines separate lanes moving in the same direction and allow lane changes."
    },
    {
        "question": "What does a construction zone sign mean?",
        "choices": [
            "It means stop before continuing",
            "A crosswalk is approaching",
            "You must stop immediately",
            "Construction may be happening and lanes may change"
        ],
        "correct": 3,
        "reason": "Construction signs warn drivers of road work and possible lane changes."
    },
    {
        "question": "How much over the speed limit can you go before getting a fine?",
        "choices": [
            "10–15 km over",
            "0–9 km over",
            "16–29 km over",
            "30–49 km over"
        ],
        "correct": 1,
        "reason": "Fines start at 10–15 km/h over the speed limit."
    },
    {
        "question": "Who has the right of way at a crosswalk?",
        "choices": [
            "The car",
            "The pedestrian",
            "Whoever arrives first",
            "The faster vehicle"
        ],
        "correct": 1,
        "reason": "Pedestrians always have the right of way at crosswalks."
    },
    {
        "question": "Is it okay to use a hand-held device when stopped at a red light?",
        "choices": [
            "True",
            "False",
            "Sometimes",
            "Depends on the situation"
        ],
        "correct": 1,
        "reason": "Using a hand-held device is illegal even when stopped at a red light."
    },
    {
        "question": "You are driving below the speed limit, but it starts raining heavily. What should you do?",
        "choices": [
            "Continue at the same speed",
            "Speed up to avoid traffic",
            "Slow down and increase following distance",
            "Pull over immediately"
        ],
        "correct": 2,
        "reason": "Drivers must adjust speed based on road and weather conditions."
    }
]


quiz_index = 0
selected_choice = None
show_result = False
quiz_score = 0
quiz_completed = False

# Quiz end buttons
quiz_menu_button = pygame.Rect(200, 300, 180, 60)
quiz_results_button = pygame.Rect(420, 300, 180, 60)

# Game tutorial button
game_start_button = pygame.Rect(300, 480, 200, 60)

answer_buttons = []
for i in range(4):
    rect = pygame.Rect(100, 200 + i * 60, 600, 50)
    answer_buttons.append(rect)

quiz_next_button = pygame.Rect(DISPLAY_WIDTH - 160, DISPLAY_HEIGHT - 65, 140, 45)

# ---------------- GAME STATE ----------------
state = "title"

# Game variables
car_x = DISPLAY_WIDTH // 2 - 80
car_y = DISPLAY_HEIGHT - 250  # Fixed position - car stays here
car_speed_x = 5  # Left/right speed
car_speed_y = 0  # Forward speed (controlled by player)
car_rotation = 0  # 0=straight, 1=left, -1=right
max_speed = 8
acceleration = 0.3
deceleration = 0.5

# Road scrolling
road_y = 0
distance_traveled = 0

current_stage = 0
show_instruction = True

# Decision question
show_decision = False
decision_made = False

# Decision buttons
decision_button_1 = pygame.Rect(150, 350, 500, 60)
decision_button_2 = pygame.Rect(150, 430, 500, 60)

# Pedestrian variables
pedestrian = {
    "x": -50,
    "y": 300,
    "speed": 2,
    "active": False
}

# ---------------- BUTTON SETUP ----------------
button_width = 140
button_height = 60
button_y = 350
spacing = 20
start_x = 10

lesson_button = pygame.Rect(start_x, button_y, button_width, button_height)
quiz_button = pygame.Rect(start_x + (button_width + spacing), button_y, button_width, button_height)
results_button = pygame.Rect(start_x + (button_width + spacing) * 2, button_y, button_width, button_height)
game_button = pygame.Rect(start_x + (button_width + spacing) * 3, button_y, button_width, button_height)
quit_button = pygame.Rect(start_x + (button_width + spacing) * 4, button_y, button_width, button_height)

start_button = pygame.Rect((DISPLAY_WIDTH - button_width) // 2, 350, button_width, button_height)

back_button = pygame.Rect(DISPLAY_WIDTH - 140, 20, 120, 45)
next_button = pygame.Rect(DISPLAY_WIDTH - 160, DISPLAY_HEIGHT - 65, 140, 45)
prev_button = pygame.Rect(20, DISPLAY_HEIGHT - 65, 140, 45)

# ---------------- FUNCTIONS ----------------
def draw_button(rect, text):
    mouse_pos = pygame.mouse.get_pos()
    color = ORANGE if rect.collidepoint(mouse_pos) else DARK_GRAY
    text_color = BLACK if rect.collidepoint(mouse_pos) else WHITE

    pygame.draw.rect(gameDisplay, color, rect)
    text_surf = button_font.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    gameDisplay.blit(text_surf, text_rect)

def draw_background():
    gameDisplay.blit(background, (0, 0))
    overlay = pygame.Surface((DISPLAY_WIDTH, DISPLAY_HEIGHT))
    overlay.set_alpha(120)
    overlay.fill(BLACK)
    gameDisplay.blit(overlay, (0, 0))
    
    
def draw_text_wrapped(text, font, color, x, y, max_width, line_spacing=5):
    words = text.split(" ")
    lines = []
    current_line = ""

    for word in words:
        test_line = current_line + word + " "
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + " "

    lines.append(current_line)

    for i, line in enumerate(lines):
        line_surf = font.render(line, True, color)
        gameDisplay.blit(line_surf, (x, y + i * (font.get_height() + line_spacing)))


def draw_title_screen():
    draw_background()
    gameDisplay.blit(title_font.render("RoadMaster", True, WHITE), (260, 180))
    gameDisplay.blit(subtitle_font.render("A driving game built on precision, awareness, and real road rules.", True, GRAY), (80, 235))
    gameDisplay.blit(paragraph_font.render("Name: Vedha Golla & Aarnaa Sekhar", True, WHITE), (30, 515))
    gameDisplay.blit(paragraph_font.render("Class Code: TEJ207", True, WHITE), (30, 535))
    gameDisplay.blit(paragraph_font.render("Teacher Name: Ms.Xie", True, WHITE), (30, 555))
    
    draw_button(start_button, "START")
    
def draw_menu_screen():
    draw_background()
    gameDisplay.blit(title_font.render("Main Menu", True, WHITE), (285, 160))
    draw_button(lesson_button, "LESSON")
    draw_button(quiz_button, "QUIZ")
    draw_button(results_button, "RESULTS")
    draw_button(game_button, "GAME")
    draw_button(quit_button, "QUIT")

def draw_lesson_screen():
    gameDisplay.blit(lesson_slides[current_slide], (0, 0))

    overlay = pygame.Surface((DISPLAY_WIDTH, DISPLAY_HEIGHT))
    overlay.set_alpha(30)
    overlay.fill((0, 0, 0))
    gameDisplay.blit(overlay, (0, 0))

    if current_slide > 0:
        draw_button(prev_button, "BACK")

    if current_slide < len(lesson_slides) - 1:
        draw_button(next_button, "NEXT")

    draw_button(back_button, "MENU")

def draw_quiz_screen():
    draw_background()

    q = quiz_questions[quiz_index]

    # Question box
    pygame.draw.rect(gameDisplay, (20, 20, 20), (60, 60, 680, 100))
    draw_text_wrapped(
        q["question"],
        subtitle_font,
        WHITE,
        80,
        75,
        640
    )

    # Answer buttons
    mouse_pos = pygame.mouse.get_pos()
    
    for i in range(4):
        rect = answer_buttons[i]
        
        # Pick button color
        if selected_choice is not None and i == selected_choice:
            # User clicked this answer
            if selected_choice == q["correct"]:
                button_color = (0, 200, 0)  # Green if correct
            else:
                button_color = (200, 50, 50)  # Red if wrong
            text_color = WHITE
        elif selected_choice is not None and i == q["correct"]:
            # Show the correct answer
            button_color = (0, 150, 0)  # Green
            text_color = WHITE
        elif rect.collidepoint(mouse_pos):
            # Mouse hovering
            button_color = ORANGE
            text_color = BLACK
        else:
            # Normal button
            button_color = (80, 80, 80)  # Lighter gray
            text_color = WHITE
        
        # Draw the button
        pygame.draw.rect(gameDisplay, button_color, rect)
        text_surf = button_font.render(q["choices"][i], True, text_color)
        text_rect = text_surf.get_rect(center=rect.center)
        gameDisplay.blit(text_surf, text_rect)

    # Feedback box
    if selected_choice is not None:
        box_y = 450
        pygame.draw.rect(gameDisplay, (30, 30, 30), (60, box_y, 680, 100))

        if selected_choice == q["correct"]:
            feedback_color = (0, 200, 0)
            feedback_text = "Correct!"
        else:
            feedback_color = (200, 60, 60)
            feedback_text = "Incorrect."

        gameDisplay.blit(
            button_font.render(feedback_text, True, feedback_color),
            (80, box_y + 10)
        )

        draw_text_wrapped(
            q["reason"],
            subtitle_font,
            WHITE,
            80,
            box_y + 50,
            640,
            line_spacing=3
        )

        draw_button(quiz_next_button, "NEXT")

    draw_button(back_button, "MENU")

def draw_quiz_end_screen():
    draw_background()
    
    # Title
    title_text = title_font.render("Quiz Complete!", True, WHITE)
    gameDisplay.blit(title_text, (200, 150))
    
    # Buttons
    draw_button(quiz_menu_button, "MENU")
    draw_button(quiz_results_button, "RESULTS")

def draw_results_screen():
    draw_background()
    
    total_questions = len(quiz_questions)
    percentage = int((quiz_score / total_questions) * 100)
    
    # Title
    title_text = title_font.render("Quiz Results", True, WHITE)
    gameDisplay.blit(title_text, (220, 80))
    
    # Score box
    pygame.draw.rect(gameDisplay, (30, 30, 30), (150, 180, 500, 280))
    
    # Percentage score 
    percent_text = title_font.render(f"{percentage}%", True, ORANGE)
    percent_rect = percent_text.get_rect(center=(400, 235))
    gameDisplay.blit(percent_text, percent_rect)
    
    # Fraction score
    fraction_text = button_font.render(f"{quiz_score} / {total_questions}", True, WHITE)
    fraction_rect = fraction_text.get_rect(center=(400, 295))
    gameDisplay.blit(fraction_text, fraction_rect)
    
    # Pass or Fail
    if percentage >= 50:
        status_text = button_font.render("PASS", True, (0, 200, 0))
        status_rect = status_text.get_rect(center=(400, 345))
        gameDisplay.blit(status_text, status_rect)
        
        # Pass message
        message = "Great job! Now practice your skills in the game mode."
        draw_text_wrapped(message, subtitle_font, WHITE, 180, 390, 440)
    else:
        status_text = button_font.render("FAIL", True, (200, 60, 60))
        status_rect = status_text.get_rect(center=(400, 345))
        gameDisplay.blit(status_text, status_rect)
        
        # Fail message
        message = "Don't give up! Review the lesson and try again."
        draw_text_wrapped(message, subtitle_font, WHITE, 180, 390, 440)
    
    draw_button(back_button, "MENU")

def draw_game_tutorial():
    draw_background()
    
    # Title
    title_text = title_font.render("How to Play", True, WHITE)
    gameDisplay.blit(title_text, (250, 60))
    
    # Tutorial box
    pygame.draw.rect(gameDisplay, (30, 30, 30), (100, 150, 600, 300))
    pygame.draw.rect(gameDisplay, ORANGE, (100, 150, 600, 300), 3)
    
    # Instructions
    y_pos = 180
    
    gameDisplay.blit(subtitle_font.render("CONTROLS:", True, ORANGE), (130, y_pos))
    y_pos += 40
    
    gameDisplay.blit(paragraph_font.render("Arrow Keys: Move your car (Up, Down, Left, Right)", True, WHITE), (150, y_pos))
    y_pos += 50
    
    gameDisplay.blit(subtitle_font.render("GOAL:", True, ORANGE), (130, y_pos))
    y_pos += 40
    
    draw_text_wrapped(
        "Complete all 4 driving challenges safely. Follow the instructor's directions and avoid collisions. If you crash or make an unsafe move, the game will restart.",
        paragraph_font, WHITE, 150, y_pos, 500, line_spacing=3)
    
    title_text = paragraph_font.render("GAME IS STILL UNDER CONSTRUCTION, IT IS STILL BUGGY", True, WHITE)
    gameDisplay.blit(title_text, (145, 130))
    
    # Start button
    draw_button(game_start_button, "START GAME")
    draw_button(back_button, "MENU")

def draw_game_screen():
    global road_y, distance_traveled, current_stage, car_x, show_decision, decision_made
    global car_speed_y, car_rotation
    
    # Determine which road to show based on distance
    current_road = straight_road
    
    # Stage progression
    if distance_traveled < 2000:
        current_road = straight_road
        current_stage = 0
    elif distance_traveled < 4000:
        current_road = straight_road
        current_stage = 0
    elif distance_traveled < 4100:
        current_stage = 0
        if not decision_made:
            show_decision = True
    elif distance_traveled < 6000:
        current_road = straight_road
        current_stage = 0
    elif distance_traveled < 8000:
        current_road = intersection_left
        current_stage = 1
    elif distance_traveled < 10000:
        current_road = straight_road
        current_stage = 2
    elif distance_traveled < 10500:  
        current_road = straight_road
        current_stage = 2
    elif distance_traveled < 12500:
        current_road = crosswalk_road
        current_stage = 3
        # Activate pedestrian LATER so you have time to slow down
        if not pedestrian["active"] and distance_traveled > 11000:
            pedestrian["active"] = True
            pedestrian["x"] = -50
    else:
        current_road = parking_lot
        current_stage = 4
    
    # Scroll the road (make two copies for seamless loop)
    gameDisplay.blit(current_road, (0, road_y))
    gameDisplay.blit(current_road, (0, road_y - DISPLAY_HEIGHT))
    
    # Update road position based on car speed
    if not show_decision:
        road_y += car_speed_y
        distance_traveled += car_speed_y
        
        # Reset when one full image has scrolled
        if road_y >= DISPLAY_HEIGHT:
            road_y = 0
    
    # Draw pedestrian
    if current_stage == 3 and pedestrian["active"]:
        pedestrian["x"] += pedestrian["speed"]
        gameDisplay.blit(pedestrian_img, (pedestrian["x"], pedestrian["y"]))
        
        # Check collision
        if (car_x < pedestrian["x"] + 40 and 
            car_x + 160 > pedestrian["x"] and
            car_y < pedestrian["y"] + 60 and
            car_y + 170 > pedestrian["y"]):
            restart_game()
        
        # Reset pedestrian
        if pedestrian["x"] > DISPLAY_WIDTH:
            pedestrian["x"] = -50
    
    # Draw player car with rotation based on steering
    if car_rotation == 1:
        current_car = player_car_left
    elif car_rotation == -1:
        current_car = player_car_right
    else:
        current_car = player_car
    
    gameDisplay.blit(current_car, (car_x, car_y))
    
    # Check parking completion
    if current_stage == 4 and car_x > 250 and car_x < 450 and car_y < 300:
        current_stage = 5
        draw_completion_screen()
        return
    
    # Draw decision popup
    if show_decision and not decision_made:
        overlay = pygame.Surface((DISPLAY_WIDTH, DISPLAY_HEIGHT))
        overlay.set_alpha(150)
        overlay.fill(BLACK)
        gameDisplay.blit(overlay, (0, 0))
        
        pygame.draw.rect(gameDisplay, (30, 30, 30), (100, 150, 600, 350))
        pygame.draw.rect(gameDisplay, ORANGE, (100, 150, 600, 350), 3)
        
        gameDisplay.blit(instructor, (120, 180))
        
        draw_text_wrapped(
            "The speed limit is 50 km/h but we are running late and there are not many cars on the road. What do you do?",
            subtitle_font,
            WHITE,
            220,
            190,
            450,
            line_spacing=5
        )
        
        mouse_pos = pygame.mouse.get_pos()
        
        color1 = ORANGE if decision_button_1.collidepoint(mouse_pos) else DARK_GRAY
        text_color1 = BLACK if decision_button_1.collidepoint(mouse_pos) else WHITE
        pygame.draw.rect(gameDisplay, color1, decision_button_1)
        choice1_text = paragraph_font.render("Speed up to reach on time", True, text_color1)
        gameDisplay.blit(choice1_text, (decision_button_1.x + 120, decision_button_1.y + 18))
        
        color2 = ORANGE if decision_button_2.collidepoint(mouse_pos) else DARK_GRAY
        text_color2 = BLACK if decision_button_2.collidepoint(mouse_pos) else WHITE
        pygame.draw.rect(gameDisplay, color2, decision_button_2)
        choice2_text = paragraph_font.render("Stay within the speed limit", True, text_color2)
        gameDisplay.blit(choice2_text, (decision_button_2.x + 120, decision_button_2.y + 18))
    
    # Draw warning before pedestrian zone
    if current_stage == 2 and distance_traveled > 10000:
        warning_text = title_font.render("⚠ SLOW DOWN!", True, (255, 200, 0))
        gameDisplay.blit(warning_text, (230, 150))
    
    # Draw instructions based on distance
    if show_instruction and not show_decision:
        instruction_text = ""
        
        if distance_traveled < 2000:
            instruction_text = "UP=Gas, DOWN=Brake, LEFT/RIGHT=Steer"
        elif distance_traveled < 4000:
            instruction_text = "Signal and continue straight."
        elif distance_traveled < 6000:
            instruction_text = "Keep driving straight."
        elif distance_traveled < 8000:
            instruction_text = "Navigate through the intersection carefully."
        elif distance_traveled < 10000:
            instruction_text = "Continue straight ahead."
        elif distance_traveled < 10500:
            instruction_text = "Pedestrian crossing ahead - prepare to slow down!"
        elif distance_traveled < 12500:
            instruction_text = "STOP for pedestrians, then proceed when clear."
        else:
            instruction_text = "Find the middle parking spot."
        
        if instruction_text and distance_traveled % 1500 < 700:
            pygame.draw.rect(gameDisplay, (20, 20, 20), (50, 20, 700, 100))
            pygame.draw.rect(gameDisplay, ORANGE, (50, 20, 700, 100), 3)
            gameDisplay.blit(instructor, (70, 35))
            draw_text_wrapped(instruction_text, subtitle_font, WHITE, 170, 40, 550)
    
    draw_button(back_button, "MENU")

def draw_completion_screen():
    pygame.draw.rect(gameDisplay, (0, 200, 0), (200, 250, 400, 100))
    pygame.draw.rect(gameDisplay, WHITE, (200, 250, 400, 100), 3)
    complete_text = title_font.render("COMPLETED!", True, WHITE)
    gameDisplay.blit(complete_text, (260, 270))
    draw_button(back_button, "MENU")

def restart_game():
    global current_stage, car_x, distance_traveled, road_y, show_decision, decision_made
    global pedestrian, car_speed_y, car_rotation
    
    draw_background()
    pygame.draw.rect(gameDisplay, (200, 0, 0), (150, 250, 500, 100))
    pygame.draw.rect(gameDisplay, WHITE, (150, 250, 500, 100), 3)
    restart_text = title_font.render("WRONG CHOICE!", True, WHITE)
    gameDisplay.blit(restart_text, (180, 270))
    
    restart_subtext = subtitle_font.render("Restarting game...", True, WHITE)
    gameDisplay.blit(restart_subtext, (280, 320))
    
    pygame.display.update()
    pygame.time.wait(2000)
    
    # Reset
    current_stage = 0
    car_x = DISPLAY_WIDTH // 2 - 80
    car_speed_y = 0
    car_rotation = 0
    distance_traveled = 0
    road_y = 0
    show_decision = False
    decision_made = False
    pedestrian["active"] = False
    pedestrian["x"] = -50

def draw_quit_screen():
    global credits_y
    gameDisplay.fill(BLACK)
    gameDisplay.blit(credits_img, (0, credits_y))
    credits_y -= scroll_speed

# ---------------- MAIN LOOP ----------------
def gameLoop():
    global state, credits_y, current_slide
    global quiz_index, selected_choice, show_result, quiz_score, quiz_completed
    global car_x, current_stage, show_instruction
    global show_decision, decision_made, road_y, distance_traveled, car_speed_y, car_rotation

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if state == "title":
                    if start_button.collidepoint(event.pos):
                        state = "menu"

                elif state == "menu":
                    if lesson_button.collidepoint(event.pos):
                        state = "lesson"
                    elif quiz_button.collidepoint(event.pos):
                        quiz_index = 0
                        quiz_score = 0
                        selected_choice = None
                        show_result = False
                        quiz_completed = False
                        state = "quiz"
                    elif results_button.collidepoint(event.pos):
                        if quiz_completed:
                            state = "results"
                        else:
                            state = "results"
                    elif game_button.collidepoint(event.pos):
                        state = "game_tutorial"
                    elif quit_button.collidepoint(event.pos):
                        credits_y = DISPLAY_HEIGHT
                        state = "quit"

                elif state == "lesson":
                    if next_button.collidepoint(event.pos) and current_slide < len(lesson_slides) - 1:
                        current_slide += 1
                    elif prev_button.collidepoint(event.pos) and current_slide > 0:
                        current_slide -= 1
                    elif back_button.collidepoint(event.pos):
                        current_slide = 0
                        state = "menu"

                elif state == "quiz":
                    if not show_result:
                        for i in range(4):
                            if answer_buttons[i].collidepoint(event.pos):
                                selected_choice = i
                                show_result = True
                                if selected_choice == quiz_questions[quiz_index]["correct"]:
                                    quiz_score += 1
                    else:
                        if quiz_next_button.collidepoint(event.pos):
                            quiz_index += 1
                            selected_choice = None
                            show_result = False
                            if quiz_index >= len(quiz_questions):
                                quiz_completed = True
                                state = "quiz_end"

                    if back_button.collidepoint(event.pos):
                        state = "menu"

                elif state == "quiz_end":
                    if quiz_menu_button.collidepoint(event.pos):
                        state = "menu"
                    elif quiz_results_button.collidepoint(event.pos):
                        state = "results"
                
                elif state == "game_tutorial":
                    if game_start_button.collidepoint(event.pos):
                        car_x = DISPLAY_WIDTH // 2 - 80
                        car_speed_y = 0
                        car_rotation = 0
                        current_stage = 0
                        road_y = 0
                        distance_traveled = 0
                        show_decision = False
                        decision_made = False
                        show_instruction = True
                        pedestrian["active"] = False
                        state = "game"
                    elif back_button.collidepoint(event.pos):
                        state = "menu"

                elif state == "results":
                    if back_button.collidepoint(event.pos):
                        state = "menu"
                
                elif state == "game":
                    # Handle decision question clicks
                    if show_decision and not decision_made:
                        if decision_button_1.collidepoint(event.pos):
                            # WRONG CHOICE
                            restart_game()
                        elif decision_button_2.collidepoint(event.pos):
                            # CORRECT CHOICE
                            show_decision = False
                            decision_made = True
                    
                    if back_button.collidepoint(event.pos):
                        state = "menu"
        
        # Game controls
        if state == "game":
            keys = pygame.key.get_pressed()
            
            # Control car speed and movement
            if not show_decision and current_stage < 5:
                # UP arrow = Accelerate
                if keys[pygame.K_UP]:
                    car_speed_y += acceleration
                    if car_speed_y > max_speed:
                        car_speed_y = max_speed
                
                # DOWN arrow = Brake/Slow down
                if keys[pygame.K_DOWN]:
                    car_speed_y -= deceleration
                    if car_speed_y < 0:
                        car_speed_y = 0
                
                # Natural deceleration if no input
                if not keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
                    car_speed_y -= 0.1
                    if car_speed_y < 0:
                        car_speed_y = 0
                
                # LEFT = Steer left (with rotation visual)
                if keys[pygame.K_LEFT]:
                    if car_x > 0:
                        car_x -= car_speed_x
                    car_rotation = 1  # Tilt left
                # RIGHT = Steer right (with rotation visual)
                elif keys[pygame.K_RIGHT]:
                    if car_x < DISPLAY_WIDTH - 160:
                        car_x += car_speed_x
                    car_rotation = -1  # Tilt right
                else:
                    car_rotation = 0  # Straight

        if state == "title":
            draw_title_screen()
        elif state == "menu":
            draw_menu_screen()
        elif state == "lesson":
            draw_lesson_screen()
        elif state == "quiz":
            draw_quiz_screen()
        elif state == "quiz_end":
            draw_quiz_end_screen()
        elif state == "results":
            draw_results_screen()
        elif state == "game_tutorial":
            draw_game_tutorial()
        elif state == "game":
            draw_game_screen()
        elif state == "quit":
            draw_quit_screen()
            if credits_y + credits_img.get_height() < 0:
                running = False

        pygame.display.update()
        clock.tick(60)

    pygame.quit()

gameLoop()